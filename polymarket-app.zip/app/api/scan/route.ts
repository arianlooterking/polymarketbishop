import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const url = 'https://gamma-api.polymarket.com/events?limit=50&active=true&closed=false&order=volume24h:DESC';
    const response = await fetch(url);
    const events = await response.json();

    const opportunities = [];

    for (const event of events) {
      if (!event.markets || !Array.isArray(event.markets)) continue;

      for (const market of event.markets) {
        if (!market.active || market.closed) continue;

        const volume = parseFloat(market.volume24h || market.volume || 0);
        if (volume < 5000) continue; // Lower threshold

        let prices = [0.5, 0.5];
        try {
          prices = JSON.parse(market.outcomePrices);
        } catch (e) {
          continue;
        }

        const yesPrice = parseFloat(prices[0]);

        // Strategy 1: "Sure Thing" (>85%)
        if (yesPrice > 0.85 && yesPrice < 0.99) {
           opportunities.push({
             strategy: 'LOW RISK',
             market: market.question,
             price: yesPrice.toFixed(3),
             profit: `${((1 - yesPrice) * 100).toFixed(1)}%`,
             volume: `$${(volume/1000).toFixed(0)}k`,
             id: market.id,
             slug: event.slug // Use event slug for cleaner links
           });
        }
        
        // Strategy 2: "Long Shot" (<15%)
        if (yesPrice < 0.15 && yesPrice > 0.02) {
           opportunities.push({
             strategy: 'HIGH REWARD',
             market: market.question,
             price: yesPrice.toFixed(3),
             profit: `${(((1 - yesPrice)/yesPrice) * 100).toFixed(0)}%`, // ROI on "Yes"
             volume: `$${(volume/1000).toFixed(0)}k`,
             id: market.id,
             slug: event.slug
           });
        }
      }
    }

    // Sort by volume
    opportunities.sort((a, b) => parseFloat(b.volume.replace('$','').replace('k','')) - parseFloat(a.volume.replace('$','').replace('k','')));

    return NextResponse.json(opportunities.slice(0, 50));
  } catch (error) {
    return NextResponse.json({ error: 'Failed to scan markets' }, { status: 500 });
  }
}
