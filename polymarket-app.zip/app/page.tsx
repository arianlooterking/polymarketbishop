'use client';

import { useState, useEffect } from 'react';
import { RefreshCcw, TrendingUp, ShieldCheck, Zap, Wallet, ExternalLink } from 'lucide-react';

interface Opportunity {
  id: string;
  slug: string;
  strategy: 'LOW RISK' | 'HIGH REWARD';
  market: string;
  price: string;
  profit: string;
  volume: string;
}

export default function Home() {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'ALL' | 'LOW RISK' | 'HIGH REWARD'>('ALL');
  const [walletConnected, setWalletConnected] = useState(false);

  const fetchOpportunities = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/scan');
      const data = await res.json();
      setOpportunities(data);
    } catch (e) {
      console.error('Failed to fetch markets', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOpportunities();
  }, []);

  const filtered = opportunities.filter(op => filter === 'ALL' || op.strategy === filter);

  return (
    <main className="min-h-screen bg-neutral-950 text-neutral-100 font-sans p-4 md:p-8">
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
            <TrendingUp className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">PolyScanner Pro</h1>
            <p className="text-neutral-400 text-sm">AI-Powered Market Intelligence</p>
          </div>
        </div>

        <div className="flex gap-3">
          <button 
            onClick={fetchOpportunities}
            className="p-2 bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors border border-neutral-700"
            title="Refresh Data"
          >
            <RefreshCcw className={`w-5 h-5 ${loading ? 'animate-spin text-blue-400' : 'text-neutral-400'}`} />
          </button>
          
          <button 
            onClick={() => setWalletConnected(!walletConnected)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
              walletConnected 
                ? 'bg-green-500/10 text-green-400 border border-green-500/30' 
                : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-500/20'
            }`}
          >
            <Wallet className="w-4 h-4" />
            {walletConnected ? '0x71...3A92' : 'Connect Wallet'}
          </button>
        </div>
      </header>

      {/* Stats / filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div 
          onClick={() => setFilter('ALL')}
          className={`p-4 rounded-xl border cursor-pointer transition-all ${filter === 'ALL' ? 'bg-neutral-900 border-blue-500/50 ring-1 ring-blue-500/30' : 'bg-neutral-900/50 border-neutral-800 hover:border-neutral-700'}`}
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-neutral-400 text-sm font-medium">Total Opportunities</span>
            <TrendingUp className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold">{opportunities.length}</div>
          <div className="text-xs text-neutral-500 mt-1">Live from Gamma API</div>
        </div>

        <div 
          onClick={() => setFilter('LOW RISK')}
          className={`p-4 rounded-xl border cursor-pointer transition-all ${filter === 'LOW RISK' ? 'bg-neutral-900 border-green-500/50 ring-1 ring-green-500/30' : 'bg-neutral-900/50 border-neutral-800 hover:border-neutral-700'}`}
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-green-400 text-sm font-medium flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Low Risk / Safe Yield
            </span>
          </div>
          <div className="text-2xl font-bold">{opportunities.filter(o => o.strategy === 'LOW RISK').length}</div>
          <div className="text-xs text-neutral-500 mt-1">Avg. Yield: 12.4%</div>
        </div>

        <div 
          onClick={() => setFilter('HIGH REWARD')}
          className={`p-4 rounded-xl border cursor-pointer transition-all ${filter === 'HIGH REWARD' ? 'bg-neutral-900 border-purple-500/50 ring-1 ring-purple-500/30' : 'bg-neutral-900/50 border-neutral-800 hover:border-neutral-700'}`}
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-purple-400 text-sm font-medium flex items-center gap-1">
              <Zap className="w-3 h-3" /> High Reward / Moonshots
            </span>
          </div>
          <div className="text-2xl font-bold">{opportunities.filter(o => o.strategy === 'HIGH REWARD').length}</div>
          <div className="text-xs text-neutral-500 mt-1">Avg. ROI: 850%</div>
        </div>
      </div>

      {/* Data Table */}
      <div className="bg-neutral-900/50 border border-neutral-800 rounded-xl overflow-hidden backdrop-blur-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-neutral-800 bg-neutral-900/80 text-xs uppercase tracking-wider text-neutral-500">
                <th className="p-4 font-medium">Strategy</th>
                <th className="p-4 font-medium w-1/2">Market</th>
                <th className="p-4 font-medium text-right">Price (Yes)</th>
                <th className="p-4 font-medium text-right">Potential Profit</th>
                <th className="p-4 font-medium text-right">Volume</th>
                <th className="p-4 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-neutral-500 animate-pulse">Scanning markets...</td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-neutral-500">No opportunities found matching criteria.</td>
                </tr>
              ) : (
                filtered.map((op) => (
                  <tr key={op.id} className="group hover:bg-neutral-800/50 transition-colors">
                    <td className="p-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                        op.strategy === 'LOW RISK' 
                          ? 'bg-green-500/10 text-green-400 border-green-500/20' 
                          : 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                      }`}>
                        {op.strategy}
                      </span>
                    </td>
                    <td className="p-4 font-medium text-neutral-200 group-hover:text-white transition-colors">
                      {op.market}
                    </td>
                    <td className="p-4 text-right font-mono text-neutral-300">${op.price}</td>
                    <td className={`p-4 text-right font-mono font-bold ${
                      op.strategy === 'LOW RISK' ? 'text-green-400' : 'text-purple-400'
                    }`}>
                      +{op.profit}
                    </td>
                    <td className="p-4 text-right text-neutral-400 text-sm">{op.volume}</td>
                    <td className="p-4 text-right">
                      <a 
                        href={`https://polymarket.com/event/${op.slug}`} 
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-blue-400 hover:text-blue-300 text-sm font-medium transition-colors"
                      >
                        Trade <ExternalLink className="w-3 h-3" />
                      </a>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </main>
  );
}
